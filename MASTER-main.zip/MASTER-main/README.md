# SSH-PLUS 
# @guizoconect

PROJETO EM DESENVOLVIMENTO...

# ESPERO QUE CURTAM O SCRIPT👽

apt update -y && apt upgrade -y && wget https://raw.githubusercontent.com/alfainternet/sshplus2/main/Plus && chmod 777 Plus && ./Plus
